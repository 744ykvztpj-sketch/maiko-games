-- SNAKE v1.4
-- LÖVE Potion / Nintendo 3DS
-- Top screen: snake game. Bottom screen: touchscreen settings.

local CELL, COLS, ROWS = 16, 20, 12
local BOARD_X, BOARD_Y = 40, 36

local snake, food
local direction, nextDirection
local timer, speed, score, gameOver
local speedMode, autoSpeed, wrapWalls = 2, true, false

local presets = {
    {name = "SLOW", value = 0.25},
    {name = "NORMAL", value = 0.16},
    {name = "FAST", value = 0.09}
}

local function baseSpeed()
    return presets[speedMode].value
end

local function opposite(a, b)
    return a.x == -b.x and a.y == -b.y
end

local function placeFood()
    repeat
        food = {x = love.math.random(1, COLS), y = love.math.random(1, ROWS)}
        local occupied = false
        for _, p in ipairs(snake) do
            if p.x == food.x and p.y == food.y then
                occupied = true
                break
            end
        end
    until not occupied
end

local function restart()
    snake = {{x=10,y=6}, {x=9,y=6}, {x=8,y=6}}
    direction = {x=1,y=0}
    nextDirection = {x=1,y=0}
    timer, score = 0, 0
    speed = baseSpeed()
    gameOver = false
    placeFood()
end

local function changeDirection(x, y)
    local d = {x=x,y=y}
    if not opposite(d, direction) and not opposite(d, nextDirection) then
        nextDirection = d
    end
end

local function moveSnake()
    direction = nextDirection
    local h = snake[1]
    local nh = {x=h.x + direction.x, y=h.y + direction.y}

    if wrapWalls then
        if nh.x < 1 then nh.x = COLS end
        if nh.x > COLS then nh.x = 1 end
        if nh.y < 1 then nh.y = ROWS end
        if nh.y > ROWS then nh.y = 1 end
    elseif nh.x < 1 or nh.x > COLS or nh.y < 1 or nh.y > ROWS then
        gameOver = true
        return
    end

    local eating = nh.x == food.x and nh.y == food.y
    local count = #snake
    if not eating then count = count - 1 end

    for i=1,count do
        if snake[i].x == nh.x and snake[i].y == nh.y then
            gameOver = true
            return
        end
    end

    table.insert(snake, 1, nh)
    if eating then
        score = score + 1
        if autoSpeed then
            speed = math.max(0.045, baseSpeed() - score * 0.004)
        end
        placeFood()
    else
        table.remove(snake)
    end
end

function love.load()
    love.graphics.setDefaultFilter("nearest", "nearest")
    love.math.setRandomSeed(os.time())
    restart()
end

function love.gamepadpressed(joystick, button)
    if button == "dpup" then changeDirection(0,-1)
    elseif button == "dpdown" then changeDirection(0,1)
    elseif button == "dpleft" then changeDirection(-1,0)
    elseif button == "dpright" then changeDirection(1,0)
    elseif button == "a" and gameOver then restart()
    elseif button == "leftshoulder" then
        speedMode = math.max(1, speedMode - 1)
        speed = baseSpeed()
    elseif button == "rightshoulder" then
        speedMode = math.min(3, speedMode + 1)
        speed = baseSpeed()
    elseif button == "x" then
        autoSpeed = not autoSpeed
        speed = baseSpeed()
    elseif button == "y" then
        wrapWalls = not wrapWalls
    elseif button == "start" then
        restart()
    end
end

local function hit(x,y,bx,by,bw,bh)
    return x >= bx and x <= bx+bw and y >= by and y <= by+bh
end

-- Touch coordinates are relative to the bottom screen.
function love.touchpressed(id, x, y, dx, dy, pressure)
    if hit(x,y,12,55,92,42) then
        speedMode = 1
        speed = baseSpeed()
    elseif hit(x,y,114,55,92,42) then
        speedMode = 2
        speed = baseSpeed()
    elseif hit(x,y,216,55,92,42) then
        speedMode = 3
        speed = baseSpeed()
    elseif hit(x,y,12,116,140,42) then
        autoSpeed = not autoSpeed
        speed = baseSpeed()
    elseif hit(x,y,168,116,140,42) then
        wrapWalls = not wrapWalls
    elseif hit(x,y,85,180,150,42) then
        restart()
    end
end

function love.update(dt)
    if gameOver then return end
    timer = timer + dt
    if timer >= speed then
        timer = timer - speed
        moveSnake()
    end
end

local function drawTop()
    love.graphics.clear(0.025,0.025,0.045)
    love.graphics.setColor(0.82,0.88,1)
    love.graphics.print("SNAKE", BOARD_X, 10)
    love.graphics.print("SCORE: "..score, BOARD_X+230, 10)

    love.graphics.setColor(0.07,0.08,0.11)
    love.graphics.rectangle("fill",BOARD_X,BOARD_Y,COLS*CELL,ROWS*CELL)

    love.graphics.setColor(0.12,0.13,0.17)
    for x=0,COLS do
        local px=BOARD_X+x*CELL
        love.graphics.line(px,BOARD_Y,px,BOARD_Y+ROWS*CELL)
    end
    for y=0,ROWS do
        local py=BOARD_Y+y*CELL
        love.graphics.line(BOARD_X,py,BOARD_X+COLS*CELL,py)
    end

    love.graphics.setColor(1,0.25,0.35)
    love.graphics.rectangle("fill",BOARD_X+(food.x-1)*CELL+3,
        BOARD_Y+(food.y-1)*CELL+3,CELL-6,CELL-6)

    for i,p in ipairs(snake) do
        if i==1 then love.graphics.setColor(0.65,1,0.68)
        else love.graphics.setColor(0.2,0.76,0.4) end
        love.graphics.rectangle("fill",BOARD_X+(p.x-1)*CELL+1,
            BOARD_Y+(p.y-1)*CELL+1,CELL-2,CELL-2)
    end

    if gameOver then
        love.graphics.setColor(0,0,0,0.88)
        love.graphics.rectangle("fill",BOARD_X+35,BOARD_Y+55,250,76)
        love.graphics.setColor(1,0.38,0.45)
        love.graphics.print("GAME OVER",BOARD_X+112,BOARD_Y+68)
        love.graphics.setColor(1,1,1)
        love.graphics.print("PRESS A OR TOUCH RESTART",BOARD_X+45,BOARD_Y+96)
    end
end

local function drawButton(x,y,w,h,label,selected)
    if selected then love.graphics.setColor(0.16,0.42,0.27)
    else love.graphics.setColor(0.13,0.15,0.21) end
    love.graphics.rectangle("fill",x,y,w,h)
    love.graphics.setColor(0.38,0.43,0.53)
    love.graphics.rectangle("line",x,y,w,h)
    love.graphics.setColor(0.92,0.94,1)
    love.graphics.printf(label,x,y+14,w,"center")
end

local function drawBottom()
    love.graphics.clear(0.035,0.04,0.065)
    love.graphics.setColor(0.82,0.88,1)
    love.graphics.print("SNAKE SETTINGS",12,16)

    love.graphics.setColor(0.58,0.63,0.74)
    love.graphics.print("choose speed",12,39)
    drawButton(12,55,92,42,"slow",speedMode==1)
    drawButton(114,55,92,42,"normal",speedMode==2)
    drawButton(216,55,92,42,"fast",speedMode==3)
    drawButton(12,116,140,42,"auto speed: "..(autoSpeed and "on" or "off"),autoSpeed)
    drawButton(168,116,140,42,"wrap walls: "..(wrapWalls and "on" or "off"),wrapWalls)
    drawButton(85,180,150,42,"restart game",false)

    love.graphics.setColor(0.58,0.63,0.74)
    love.graphics.printf("touch buttons to change settings",8,230,304,"center")
end

-- LÖVE Potion calls love.draw once for each screen.
-- The screen argument is "left", "right", or "bottom" on a 3DS.
function love.draw(screen)
    if screen == "bottom" then
        drawBottom()
    else
        drawTop()
    end
end
